def count_in_list(lst: list, s: str) -> int:
    return lst.count(s)
